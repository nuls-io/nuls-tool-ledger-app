Operating Orders:

python -m ledgerblue.runScript --help (Print help information)
python -m ledgerblue.runScript --scp --fileName bin/app.apdu --elfFile bin/app.elf (To pack up the firmware.)


